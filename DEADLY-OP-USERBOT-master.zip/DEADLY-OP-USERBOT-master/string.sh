#!/bin/bash


echo """
                      © LEGENDRY_AF_DEADLYBOT™
           
"""

python3 string_session.py
