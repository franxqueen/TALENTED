#!/bin/bash

echo """
             
                       LEGENDRY AF DEADLYBOT!!
                                          @deadly_userbot
"""

python3 -m userbot
